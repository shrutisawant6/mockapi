﻿namespace MockAPI.DTOs.Response
{
    public class AssetsDto
    {
        public List<AssetDto> Items { get; set; }
    }
}
