﻿namespace MockAPI.DTOs.Response
{
    public class DeleteAssetDto
    {
        public string Message { get; set; }
    }
}
