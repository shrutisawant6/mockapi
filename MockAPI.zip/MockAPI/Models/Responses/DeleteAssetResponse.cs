﻿namespace MockAPI.Models.Responses
{
    public class DeleteAssetResponse
    {
        public string Message { get; set; }
    }
}
