﻿using Newtonsoft.Json;

namespace MockAPI.Models.Responses
{
    public class Assets
    {
        public List<Asset> Items { get; set; }
    }
}
